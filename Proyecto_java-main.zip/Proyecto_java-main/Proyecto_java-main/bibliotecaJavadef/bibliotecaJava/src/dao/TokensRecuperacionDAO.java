/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import modelo.TokenRecuperacion;
import conexion.ConexionSupabasePooler;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO para manejar operaciones CRUD sobre la tabla tokens_recuperacion.
 * Permite insertar, consultar, actualizar y eliminar tokens de recuperación de contraseña.
 */
public class TokensRecuperacionDAO {

    /**
     * Obtiene todos los tokens de recuperación existentes.
     */
    public List<TokenRecuperacion> obtenerTokens() {
        List<TokenRecuperacion> lista = new ArrayList<>();
        String sql = "SELECT id, id_usuario, token, fecha_expiracion, usado, ip_solicitud, created_at FROM tokens_recuperacion";
        try (Connection conn = ConexionSupabasePooler.conectar();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                TokenRecuperacion token = new TokenRecuperacion(
                    rs.getInt("id"),
                    rs.getInt("id_usuario"),
                    rs.getString("token"),
                    rs.getTimestamp("fecha_expiracion"),
                    rs.getBoolean("usado"),
                    rs.getString("ip_solicitud"),
                    rs.getTimestamp("created_at")
                );
                lista.add(token);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    /**
     * Inserta un nuevo token de recuperación.
     */
    public boolean insertarToken(TokenRecuperacion token) {
        String sql = "INSERT INTO tokens_recuperacion (id_usuario, token, fecha_expiracion, usado, ip_solicitud, created_at) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = ConexionSupabasePooler.conectar();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, token.getIdUsuario());
            ps.setString(2, token.getToken());
            ps.setTimestamp(3, token.getFechaExpiracion());
            ps.setBoolean(4, token.isUsado());
            ps.setString(5, token.getIpSolicitud());
            ps.setTimestamp(6, token.getCreatedAt());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Actualiza los datos de un token existente.
     */
    public boolean actualizarToken(TokenRecuperacion token) {
        String sql = "UPDATE tokens_recuperacion SET id_usuario=?, token=?, fecha_expiracion=?, usado=?, ip_solicitud=?, created_at=? WHERE id=?";
        try (Connection conn = ConexionSupabasePooler.conectar();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, token.getIdUsuario());
            ps.setString(2, token.getToken());
            ps.setTimestamp(3, token.getFechaExpiracion());
            ps.setBoolean(4, token.isUsado());
            ps.setString(5, token.getIpSolicitud());
            ps.setTimestamp(6, token.getCreatedAt());
            ps.setInt(7, token.getId());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Elimina un token por su ID.
     */
    public boolean eliminarToken(int id) {
        String sql = "DELETE FROM tokens_recuperacion WHERE id=?";
        try (Connection conn = ConexionSupabasePooler.conectar();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}