/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import modelo.Prestamo;
import conexion.ConexionSupabasePooler;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PrestamosDAO {

    public List<Prestamo> obtenerPrestamos() {
        List<Prestamo> lista = new ArrayList<>();
        String sql = "SELECT id, id_usuario, id_libro, fecha_prestamo, fecha_devolucion FROM prestamos";
        try (Connection conn = ConexionSupabasePooler.conectar();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Prestamo prestamo = new Prestamo(
                    rs.getInt("id"),
                    rs.getInt("id_usuario"),
                    rs.getInt("id_libro"),
                    rs.getDate("fecha_prestamo"),
                    rs.getDate("fecha_devolucion")
                );
                lista.add(prestamo);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public boolean insertarPrestamo(Prestamo prestamo) {
        String sql = "INSERT INTO prestamos (id_usuario, id_libro, fecha_prestamo, fecha_devolucion) VALUES (?, ?, ?, ?)";
        try (Connection conn = ConexionSupabasePooler.conectar();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, prestamo.getIdUsuario());
            ps.setInt(2, prestamo.getIdLibro());
            ps.setDate(3, new java.sql.Date(prestamo.getFechaPrestamo().getTime()));
            ps.setDate(4, new java.sql.Date(prestamo.getFechaDevolucion().getTime()));
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean actualizarPrestamo(Prestamo prestamo) {
        String sql = "UPDATE prestamos SET id_usuario=?, id_libro=?, fecha_prestamo=?, fecha_devolucion=? WHERE id=?";
        try (Connection conn = ConexionSupabasePooler.conectar();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, prestamo.getIdUsuario());
            ps.setInt(2, prestamo.getIdLibro());
            ps.setDate(3, new java.sql.Date(prestamo.getFechaPrestamo().getTime()));
            ps.setDate(4, new java.sql.Date(prestamo.getFechaDevolucion().getTime()));
            ps.setInt(5, prestamo.getId());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean eliminarPrestamo(int id) {
        String sql = "DELETE FROM prestamos WHERE id=?";
        try (Connection conn = ConexionSupabasePooler.conectar();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}