/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import modelo.Libro;
import conexion.ConexionSupabasePooler;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO para la tabla libros, usando categoría normalizada.
 */
public class LibrosDAO {
    public List<Libro> obtenerLibros() {
        List<Libro> lista = new ArrayList<>();
        String sql = "SELECT id_libro, nombre, autor, editorial, paginas, isbn, id_categoria, fecha_publicacion, precio, stock_total, stock_disponible, activo, created_at, updated_at FROM libros";
        try (Connection conn = ConexionSupabasePooler.conectar();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Libro libro = new Libro(
                    rs.getInt("id_libro"),
                    rs.getString("nombre"),
                    rs.getString("autor"),
                    rs.getString("editorial"),
                    rs.getInt("paginas"),
                    rs.getString("isbn"),
                    rs.getInt("id_categoria"),
                    rs.getDate("fecha_publicacion"),
                    rs.getDouble("precio"),
                    rs.getInt("stock_total"),
                    rs.getInt("stock_disponible"),
                    rs.getBoolean("activo"),
                    rs.getTimestamp("created_at"),
                    rs.getTimestamp("updated_at")
                );
                lista.add(libro);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    // Métodos insertarLibro, actualizarLibro y eliminarLibro igual que antes, pero usando id_categoria

    /**
     * Obtiene libros filtrados por categoría.
     */
    public List<Libro> obtenerLibrosPorCategoria(int idCategoria) {
        List<Libro> lista = new ArrayList<>();
        String sql = "SELECT id_libro, nombre, autor, editorial, paginas, isbn, id_categoria, fecha_publicacion, precio, stock_total, stock_disponible, activo, created_at, updated_at FROM libros WHERE id_categoria=?";
        try (Connection conn = ConexionSupabasePooler.conectar();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idCategoria);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Libro libro = new Libro(
                        rs.getInt("id_libro"),
                        rs.getString("nombre"),
                        rs.getString("autor"),
                        rs.getString("editorial"),
                        rs.getInt("paginas"),
                        rs.getString("isbn"),
                        rs.getInt("id_categoria"),
                        rs.getDate("fecha_publicacion"),
                        rs.getDouble("precio"),
                        rs.getInt("stock_total"),
                        rs.getInt("stock_disponible"),
                        rs.getBoolean("activo"),
                        rs.getTimestamp("created_at"),
                        rs.getTimestamp("updated_at")
                    );
                    lista.add(libro);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
}