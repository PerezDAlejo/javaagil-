package modelo;


/**
 * Modelo para la tabla libros, con relación a la categoría normalizada.
 */
public class Libro {
    private int idLibro;
    private String nombre;
    private String autor;
    private String editorial;
    private int paginas;
    private String isbn;
    private int idCategoria;
    private java.sql.Date fechaPublicacion;
    private double precio;
    private int stockTotal;
    private int stockDisponible;
    private boolean activo;
    private java.sql.Timestamp createdAt;
    private java.sql.Timestamp updatedAt;

    public Libro() {}

    public Libro(int idLibro, String nombre, String autor, String editorial, int paginas, String isbn, int idCategoria,
                 java.sql.Date fechaPublicacion, double precio, int stockTotal, int stockDisponible,
                 boolean activo, java.sql.Timestamp createdAt, java.sql.Timestamp updatedAt) {
        this.idLibro = idLibro;
        this.nombre = nombre;
        this.autor = autor;
        this.editorial = editorial;
        this.paginas = paginas;
        this.isbn = isbn;
        this.idCategoria = idCategoria;
        this.fechaPublicacion = fechaPublicacion;
        this.precio = precio;
        this.stockTotal = stockTotal;
        this.stockDisponible = stockDisponible;
        this.activo = activo;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    // Getters y setters
    // ...
}