/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.sql.Timestamp;

/**
 * Modelo para la tabla tokens_recuperacion.
 * Representa los datos de los tokens de recuperación de contraseña.
 */
public class TokenRecuperacion {
    private int id;                  // Identificador único
    private int idUsuario;           // ID del usuario relacionado
    private String token;            // Token generado
    private Timestamp fechaExpiracion; // Fecha de expiración del token
    private boolean usado;           // Si el token ya fue usado
    private String ipSolicitud;      // IP desde donde se solicitó
    private Timestamp createdAt;     // Fecha de creación

    public TokenRecuperacion() {}

    public TokenRecuperacion(int id, int idUsuario, String token, Timestamp fechaExpiracion, boolean usado, String ipSolicitud, Timestamp createdAt) {
        this.id = id;
        this.idUsuario = idUsuario;
        this.token = token;
        this.fechaExpiracion = fechaExpiracion;
        this.usado = usado;
        this.ipSolicitud = ipSolicitud;
        this.createdAt = createdAt;
    }

    // Getters y setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getIdUsuario() { return idUsuario; }
    public void setIdUsuario(int idUsuario) { this.idUsuario = idUsuario; }

    public String getToken() { return token; }
    public void setToken(String token) { this.token = token; }

    public Timestamp getFechaExpiracion() { return fechaExpiracion; }
    public void setFechaExpiracion(Timestamp fechaExpiracion) { this.fechaExpiracion = fechaExpiracion; }

    public boolean isUsado() { return usado; }
    public void setUsado(boolean usado) { this.usado = usado; }

    public String getIpSolicitud() { return ipSolicitud; }
    public void setIpSolicitud(String ipSolicitud) { this.ipSolicitud = ipSolicitud; }

    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }
}