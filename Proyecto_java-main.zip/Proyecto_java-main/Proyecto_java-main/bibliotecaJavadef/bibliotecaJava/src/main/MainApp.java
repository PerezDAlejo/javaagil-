package main;

import vista.frmRegistro; // <--- asegúrate de tener este import

import javax.swing.*;

public class MainApp {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new frmRegistro().setVisible(true);
        });
    }
}