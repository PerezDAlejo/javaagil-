package conexion;

import java.sql.Connection;
import java.sql.SQLException;

public class PruebaConexionSupabase {
    public static void main(String[] args) {
        try {
            Connection conn = ConexionSupabasePooler.conectar();
            if (conn != null && !conn.isClosed()) {
                System.out.println("¡Conexión exitosa a Supabase/Postgres!");
                conn.close();
            } else {
                System.out.println("No se pudo establecer la conexión.");
            }
        } catch (SQLException e) {
            System.out.println("Error al conectar: " + e.getMessage());
            e.printStackTrace();
        }
    }
}