package conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionSupabasePooler {
    // Cambia estos datos por los de tu proyecto en Supabase
    private static final String URL = "jdbc:postgresql://aws-1-sa-east-1.pooler.supabase.com:6543/postgres";
    private static final String USUARIO = "postgres.kpbxlpceugkodngjkkqe";
    private static final String PASSWORD = "Alejo12300.*";

    public static Connection conectar() throws SQLException {
        return DriverManager.getConnection(URL, USUARIO, PASSWORD);
    }
}