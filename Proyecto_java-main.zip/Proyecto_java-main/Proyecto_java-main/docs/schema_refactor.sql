-- =========================================
-- Esquema optimizado para Supabase/Postgres
-- =========================================

-- =========================================
-- TABLA: categorias
-- =========================================
CREATE TABLE categorias (
    id_categoria SERIAL PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL UNIQUE,
    descripcion TEXT
);

-- =========================================
-- TABLA: usuarios
-- =========================================
CREATE TABLE usuarios (
    id SERIAL PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    correo VARCHAR(150) NOT NULL UNIQUE,
    clave VARCHAR(255),
    password_hash VARCHAR(255),
    rol VARCHAR(10) NOT NULL DEFAULT 'usuario',
    activo BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =========================================
-- TABLA: libros
-- =========================================
CREATE TABLE libros (
    id_libro SERIAL PRIMARY KEY,
    nombre VARCHAR(200) NOT NULL,
    autor VARCHAR(150) NOT NULL,
    editorial VARCHAR(100) NOT NULL,
    paginas INT NOT NULL,
    isbn VARCHAR(20) NOT NULL UNIQUE,
    id_categoria INT NOT NULL REFERENCES categorias(id_categoria) ON DELETE RESTRICT ON UPDATE CASCADE,
    fecha_publicacion DATE,
    precio DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    stock_total INT NOT NULL DEFAULT 1,
    stock_disponible INT NOT NULL DEFAULT 1,
    activo BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CHECK (stock_disponible >= 0 AND stock_disponible <= stock_total),
    CHECK (stock_total >= 0),
    CHECK (precio >= 0)
);

-- =========================================
-- TABLA: prestamos
-- =========================================
CREATE TABLE prestamos (
    id SERIAL PRIMARY KEY,
    id_usuario INT NOT NULL REFERENCES usuarios(id) ON DELETE RESTRICT ON UPDATE CASCADE,
    id_libro INT NOT NULL REFERENCES libros(id_libro) ON DELETE RESTRICT ON UPDATE CASCADE,
    fecha_prestamo TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_devolucion_esperada DATE NOT NULL,
    fecha_devolucion_real TIMESTAMP,
    estado VARCHAR(10) NOT NULL DEFAULT 'PENDIENTE',
    observaciones TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CHECK (fecha_devolucion_esperada >= fecha_prestamo)
);

-- =========================================
-- TABLA: tokens_recuperacion
-- =========================================
CREATE TABLE tokens_recuperacion (
    id SERIAL PRIMARY KEY,
    id_usuario INT NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE ON UPDATE CASCADE,
    token VARCHAR(255) NOT NULL UNIQUE,
    fecha_expiracion TIMESTAMP NOT NULL,
    usado BOOLEAN NOT NULL DEFAULT FALSE,
    ip_solicitud VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =========================================
-- VISTAS ÚTILES PARA CONSULTAS FRECUENTES
-- =========================================

CREATE VIEW v_libros_disponibles AS
SELECT 
    l.id_libro,
    l.nombre,
    l.autor,
    l.editorial,
    c.nombre AS categoria,
    l.stock_total,
    l.stock_disponible,
    CASE 
        WHEN l.stock_disponible > 0 THEN 'DISPONIBLE'
        ELSE 'AGOTADO'
    END as disponibilidad
FROM libros l
JOIN categorias c ON l.id_categoria = c.id_categoria
WHERE l.activo = TRUE;

CREATE VIEW v_prestamos_activos AS
SELECT 
    p.id,
    u.nombre as usuario,
    u.correo,
    l.nombre as libro,
    l.autor,
    p.fecha_prestamo,
    p.fecha_devolucion_esperada,
    p.estado,
    CASE 
        WHEN p.fecha_devolucion_esperada < CURRENT_DATE AND p.estado IN ('APROBADO', 'PENDIENTE') THEN 'VENCIDO'
        ELSE p.estado
    END as estado_actual
FROM prestamos p
JOIN usuarios u ON p.id_usuario = u.id
JOIN libros l ON p.id_libro = l.id_libro
WHERE p.estado IN ('PENDIENTE', 'APROBADO');